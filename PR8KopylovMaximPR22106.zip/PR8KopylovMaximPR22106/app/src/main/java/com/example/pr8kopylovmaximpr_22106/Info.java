package com.example.pr8kopylovmaximpr_22106;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Info extends AppCompatActivity implements View.OnClickListener {

    Button bt;
     ImageButton bt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info);
        bt = findViewById(R.id.button5);
        bt.setOnClickListener(this);
        bt1 = findViewById(R.id.imageButton2);
        bt1.setOnClickListener(this);


    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button5:
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"));
                startActivity(intent);
                break;
            case R.id.imageButton2:
                startActivity(new Intent(this,Pets.class));
                break;
        }
    }
}